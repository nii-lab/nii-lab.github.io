# AI Applications

Open **index.html**.

[Author & use](reuse.html)
